<h2><u>Работать с отзывы от клиентов</u></h2>

<div id="content-page" class="content group">
				            <div class="hentry group">

<!-- summernote css/js -->
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.js"></script>

    <?php if($errors = Session::get('errors')): ?>
	<div class="alert alert-danger">
	<button class="close" data-dismiss="alert">×</button>
	<ul>
		<?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<li><?php echo e($error); ?></li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ul>
	</div>									
    <?php endif; ?>
    <?php if($error = Session::get('error')): ?>
	<div class="alert alert-danger">
	<button class="close" data-dismiss="alert">×</button>
	<strong><?php echo e($error); ?></strong>
	</div>									
    <?php endif; ?>

<?php echo Form::open(['url' => (isset($otzivi->id)) ? route('otziv.update',['otziv'=>$otzivi->id]) : route('otziv.store'),'class'=>'contact-form','method'=>'POST','enctype'=>'multipart/form-data']); ?>




  <div class="col-md-12">
      

 

                         
              

    <div class="input-prepend"><span class="add-on">

<i class="icon-user"></i></span>
Имя:<strong style="color:red;">*</strong> 

<input class="form-control" placeholder="Введите название страницы" name="name" value="<?php echo e(isset($otzivi->name)?$otzivi->name:''); ?>" type="text">

 </div>

      <div class="input-prepend"><span class="add-on">

      <i class="icon-user"></i></span>
    

<br />
      Текст :<strong style="color:red;">*</strong> 
      <textarea id='summernote' class= 'form-control' placeholder='Введите текст страницы' name="text"><?php echo e(isset($otzivi->name)?$otzivi->text:''); ?> </textarea>


      

       </div>
		<?php if(isset($otzivi->id)): ?>
			<input type="hidden" name="_method" value="PUT">

		<?php endif; ?>

<br />


<div class="row">
	<div class="col-md-6">
		      Загрузка качественный фото:
  <input type="file" name="img" id="file" size="2048">
Размер <strong> 1 МБ</strong> (в формате <strong>.png, .gif, .jpeg, .jpg </strong>) файл можно отправить 
	</div>
<?php if(isset($otzivi->name)): ?>
	<div class="col-md-6">
            <?php if(!empty($otzivi->img)): ?>
    <img class="d-flex align-self-start mr-3 img-thumbnail" align="left" style="width: 160px;" src="<?php echo e(asset('/users/'.$otzivi->img)); ?>" alt="<?php echo e($otzivi->name); ?>">
    <?php else: ?>
        <img class="d-flex align-self-start mr-3 img-thumbnail" align="left" style="width: 160px;" src="<?php echo e(asset('/users/user.png')); ?>" alt="<?php echo e($otzivi->name); ?>">
    <?php endif; ?>
	</div>
	<?php endif; ?>
</div>
<br />

		<br />

	<?php echo Form::button('Сохранить', ['class' => 'btn btn-block btn-success btn-flat','type'=>'submit']); ?>


<?php echo Form::close(); ?>







</div>
</div>


<!-- summernote css/js -->
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.js"></script>
<script type="text/javascript">
    $('#summernote*').summernote({
        height: 100
    });
</script>


<?php /**PATH /var/www/eosts/resources/views/eosts/admin/otziv/otziv_create_content.blade.php ENDPATH**/ ?>