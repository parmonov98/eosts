 <?php if(!session()->has('lang')){session()->put('lang', 'ru');  }$lang = session('lang'); ?>
            


<!-- Client Reviews Start -->
            <section class="wide-tb-100 mb-spacer-md">
                <div class="container">
                    <div class="row">
                        <!-- Heading Main -->
                        <div class="col-sm-12 wow fadeInDown" data-wow-duration="0" data-wow-delay="0s">
                            <h1 class="heading-main">

                                <?php echo ('ru'==$lang)?'<span>Комментарии</span> Отзывы от клиентов':''; ?> <?php echo ('en'==$lang)?'<span>Comments</span> Reviews from client':''; ?> <?php echo ('tu'==$lang)?'<span>Yorumlar</span> Reviews from client':''; ?>


                                
                            </h1>
                        </div>
                        <!-- Heading Main -->

                        <div class="col-sm-12">
                            <div class="owl-carousel owl-theme" id="home-client-testimonials">


<?php $__currentLoopData = $otzivi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <!-- Client Testimonials Slider Item -->
                                <div class="item" itemprop="review" itemscope itemtype="https://schema.org/Review">
                                    <div class="client-testimonial bg-wave">
                                        <div class="media">
                                            <div class="client-testimonial-icon rounded-circle bg-navy-blue">
                                                <img src="<?php echo e(asset('/users/'.$value->img)); ?>" alt="">
                                            </div>
                                            <div class="client-inner-content media-body">
                                               <div style="    height: 200px;  overflow: auto;    margin-bottom: 11px;"> <?php echo $value->text; ?></div>
                                                
                                                <footer class="blockquote-footer"><cite title="Source Title">
                                                        <span itemprop="author"> <?php echo e($value->name); ?> </span> </cite>
                                                </footer> 
                                            
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Client Testimonials Slider Item -->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </section><?php /**PATH /var/www/eosts/resources/views/eosts/otzivi.blade.php ENDPATH**/ ?>