<?php $__env->startSection('navigation'); ?>
	<?php echo $navigation; ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
	<?php echo $content; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
	<?php echo $footer; ?>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make(config('settings.theme').'.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/eosts/resources/views/eosts/admin/contact/contact.blade.php ENDPATH**/ ?>