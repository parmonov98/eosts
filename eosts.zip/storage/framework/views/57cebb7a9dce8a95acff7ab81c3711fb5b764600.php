<?php
    if(!session()->has('lang')){
            session()->put('lang', 'oz');
        }
    $lang = session('lang');

$public = substr($_SERVER['REQUEST_URI'], 1,6);  
?>
<?php if($menu): ?>
                        <ul class="navbar-nav ml-auto" itemprop="about" itemscope="" itemtype="#">

                            <li>
                                <a href="/" >
<i class="icofont-simple-right"></i><span><?php echo e(('ru'==$lang)?'Главная':''); ?><?php echo e(('en'==$lang)?'Address':''); ?><?php echo e(('tu'==$lang)?'Address':''); ?></span>
                                </a>
                            </li>
                            
                      
<?php echo $__env->make(env('THEME').'.customMenuItemsfut',['items'=>$menu->roots()], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 </ul>
<?php endif; ?><?php /**PATH /var/www/eosts/resources/views/eosts/futnav.blade.php ENDPATH**/ ?>