
	<div id="content-page" class="content group">
				            <div class="hentry group">
				                <h2>Xizmat menejeri</h2>
									<?php if($status = Session::get('status')): ?>
									<div class="alert alert-success">
									<button class="close" data-dismiss="alert">×</button>
									<strong><?php echo e($status); ?></strong>
									</div>
									<?php endif; ?>
							
			<!-- <a class="btn btn-primary btn-lg " href="<?php echo e(route('uslug.create')); ?>"><i class="fa fa-plus"></i></a> -->
		
<hr  style="margin-top: 10px;margin-bottom: 10px;border-top: 1px #9e9e9e dotted;">
				                <div class="short-table white">
		<div class="tournamentsTable">
<?php if($uslugi->count()>0): ?>
				        <table  class="table table-striped table-hover" style="width: 100%" cellspacing="0" cellpadding="0">
				                        <thead>
				                            <tr >
				                                <th style="width: 50px;text-align: center;">ID</th>
				                                <th>Sarlavha</th>
				                               <th style="width: 100px;text-align: center;">Rasm</th>

				                                <th style="width: 50px;text-align: center;"><i class="fa fa-pencil-square-o"></i></th>
				                                <th style="width: 50px;text-align: center;"><i class="fa fa-trash-o"></i></th>
				                            </tr>
				                        </thead>
				                        <tbody>

											<?php $__currentLoopData = $uslugi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uslug): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											
											<tr>
				                                <td style="text-align: center;"><?php echo e($uslug->id); ?></td>
		                                <td class="align-left">		                               
		                                	<?php echo e($uslug->title['ru']); ?>   
		                               </td>

				                                <td align="center">
													<?php if(isset($uslug->img['min'])): ?>

				<?php echo e(Html::image(asset('/uslugi/'.$uslug->img['min']),'',['style'=>'width:50px;'])); ?>

													<?php endif; ?>
												</td>
				                                <td><a href="<?php echo e(route('uslug.edit',['uslug'=>$uslug->id])); ?>" class="btn btn-success"><i class="fa fa-pencil-square-o"></i></a></td>

				                   

				                                <td>
								

												<?php echo Form::open(['url' => route('uslug.destroy',['uslug'=>$uslug->id]),'class'=>'form-horizontal','method'=>'POST']); ?>

												    <?php echo e(method_field('DELETE')); ?>

												    <?php echo Form::button('<i class="fa fa-trash-o"></i>', ['class' => 'btn btn-danger','type'=>'submit']); ?>

												<?php echo Form::close(); ?>

									


												</td>
											 </tr>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				                        </tbody>
				                    </table>
				                </div>





         <?php endif; ?>
			        </div>
				            </div>



				            <!-- START COMMENTS -->

				            <div class="wrap_result"></div>
				          <?php if($uslugi): ?>
				          <div id="pagination" align="center">

                      <?php echo e($uslugi->appends(request()->except('page'))->links()); ?>


				            <!-- END COMMENTS -->
				            </div>
				          <?php endif; ?>


                        </div>




<?php /**PATH /var/www/eosts/resources/views/eosts/admin/uslugi/uslugi_content.blade.php ENDPATH**/ ?>