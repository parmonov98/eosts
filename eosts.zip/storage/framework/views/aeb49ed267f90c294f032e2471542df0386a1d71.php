	<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

 <li>

        <a  href="<?php echo e($item->url()); ?>">
<i class="icofont-simple-right"></i><span><?php echo e($item->title); ?></span></a>
    </li>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /var/www/eosts/resources/views/eosts/customMenuItemsfut.blade.php ENDPATH**/ ?>