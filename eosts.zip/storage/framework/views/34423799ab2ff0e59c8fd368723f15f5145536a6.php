

<?php if(count($gallerys[0])>0): ?>

           <section class="bg-light-gray wide-tb-100">
                <div class="container pos-rel">
                    <div class="row">
                        <!-- Heading Main -->
                        <div class="col-sm-12 wow fadeInDown" data-wow-duration="0" data-wow-delay="0s">
                            <h1 class="heading-main">

                                <?php echo ('ru'==$gallerys[1])?'<span>наша </span>фотогалерея':''; ?> <?php echo ('en'==$gallerys[1])?'<span> our </span> Photo gallery':''; ?> <?php echo ('tu'==$gallerys[1])?'<span>bizim  </span> fotoğraf Galerisi':''; ?> 

                                  
                            </h1>
                        </div>
                        <!-- Heading Main -->
                    </div>

                    <div id="js-styl2-mosaic" class="cbp" itemscope itemtype="https://schema.org/ImageObject">
                        

<?php $__currentLoopData = $gallerys[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="cbp-item <?php if($gallery->sezi == 1): ?> design <?php elseif($gallery->sezi == 2): ?> identity <?php else: ?> photography <?php endif; ?>" itemprop="">
                            <div class="gallery-link">
                                <a href="<?php echo e(asset('/gallery/'.$gallery->img['max'])); ?>" class="txt-white">
                                    <i class="icofont-external-link"></i>
                                </a>
                            </div>
                            <a href="<?php echo e(asset('/gallery/'.$gallery->img['max'])); ?>" itemprop="contentUrl" class="cbp-caption cbp-lightbox"
                                data-title="<?php echo e(isset($gallery->name['name'][$gallerys[1]])?$gallery->name['name'][$gallerys[1]]:''); ?>" itemscope itemtype="https://schema.org/ImageObject">
                                <div class="cbp-caption-defaultWrap">
                                    <img src="<?php echo e(asset('/gallery/'.$gallery->img['min'])); ?>" itemprop="contentUrl" alt="Somehere <?php echo e($gallery->id); ?>" >
                                </div>
                                <div class="cbp-caption-activeWrap">
                                    <div class="cbp-l-caption-alignCenter">
                                        <div class="cbp-l-caption-body">
                                            <i class="icofont-search icofont-2x txt-white"></i>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                       





                    </div>

                </div>
            </section>


            <?php endif; ?><?php /**PATH /var/www/eosts/resources/views/eosts/gallery.blade.php ENDPATH**/ ?>