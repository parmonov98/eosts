<h2><u>Kompaniya manzili</u></h2>
          <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
              <button class="close" data-dismiss="alert">×</button>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
          <?php endif; ?>
<div id="content-page" class="content group">
				            <div class="hentry group">

<?php echo Form::open(['url' => route('setAddressup') ,'class'=>'contact-form','method'=>'POST','enctype'=>'multipart/form-data']); ?>


			<div class="input-prepend">
				
				
<div class="row">
  <div class="col-md-6">
<h3>Buxoro</h3>
				<i class="fa fa-map-marker"></i> Русский:
				<input type="text" name="addres[bux][ru]" value="<?php echo e(isset($setname['address']['addres']['bux']['ru']) ? $setname['address']['addres']['bux']['ru'] : ''); ?>" placeholder="Русский" class="form-control">

				<i class="fa fa-map-marker"></i> English:
				<input type="text" name="addres[bux][en]" value="<?php echo e(isset($setname['address']['addres']['bux']['en']) ? $setname['address']['addres']['bux']['en'] : ''); ?>" placeholder="English" class="form-control">

				<i class="fa fa-map-marker"></i> Türkçe:
				<input type="text" name="addres[bux][tu]" value="<?php echo e(isset($setname['address']['addres']['bux']['tu']) ? $setname['address']['addres']['bux']['tu']  : ''); ?>" placeholder="Türkçe" class="form-control">  	

  </div>
  <div class="col-md-6">
  	<h3>Toshkent</h3>
				<i class="fa fa-map-marker"></i> Русский:
				<input type="text" name="addres[tosh][ru]" value="<?php echo e(isset($setname['address']['addres']['tosh']['ru']) ? $setname['address']['addres']['tosh']['ru'] : ''); ?>" placeholder="Русский" class="form-control">

				<i class="fa fa-map-marker"></i> English:
				<input type="text" name="addres[tosh][en]" value="<?php echo e(isset($setname['address']['addres']['tosh']['en']) ? $setname['address']['addres']['tosh']['en'] : ''); ?>" placeholder="English" class="form-control">

				<i class="fa fa-map-marker"></i> Türkçe:
				<input type="text" name="addres[tosh][tu]" value="<?php echo e(isset($setname['address']['addres']['tosh']['tu']) ? $setname['address']['addres']['tosh']['tu']  : ''); ?>" placeholder="Türkçe" class="form-control">  	
  </div>
</div>





			<hr>

			<i class="fa fa-phone"></i> Telefon 1:
			<input type="text" name="phone[]" value="<?php echo e(isset($setname['address']['phone'][0]) ? $setname['address']['phone'][0] : ''); ?>" placeholder="Telefon" class="form-control">
			<i class="fa fa-phone"></i> Telefon 2:
			<input type="text" name="phone[]" value="<?php echo e(isset($setname['address']['phone'][1]) ? $setname['address']['phone'][1] : ''); ?>" placeholder="Telefon" class="form-control">			

			<i class="fa fa-envelope"></i> E-mail 1:
			<input type="email" name="email[]" value="<?php echo e(isset($setname['address']['email'][0]) ? $setname['address']['email'][0] : ''); ?>" placeholder="E-mail" class="form-control">
			<i class="fa fa-envelope"></i> E-mail 2:
			<input type="email" name="email[]" value="<?php echo e(isset($setname['address']['email'][1]) ? $setname['address']['email'][1] : ''); ?>" placeholder="E-mail" class="form-control">			
			 </div>

    		<hr>
		</div>
						<?php echo Form::button('Saqlash', ['class' => 'btn btn-block btn-success btn-flat','type'=>'submit']); ?>



<?php echo Form::close(); ?>


</div><?php /**PATH /var/www/eosts/resources/views/eosts/admin/settings/address_content.blade.php ENDPATH**/ ?>