  <!-- Page Breadcrumbs Start -->
    <div class="slider bg-navy-blue bg-scroll pos-rel breadcrumbs-page">
      <div class="container">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/"><i class="icofont-home"></i></a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo e(('ru'==$cat)?'Услуги':''); ?> <?php echo e(('en'==$cat)?'Services':''); ?> <?php echo e(('tu'==$cat)?'Hizmetler':''); ?></li>
          </ol>
        </nav>

        <h1><?php echo e(('ru'==$cat)?'Наши сервисы':''); ?> <?php echo e(('en'==$cat)?'Our services':''); ?> <?php echo e(('tu'==$cat)?'Hizmetlerimiz':''); ?></h1>
        <div class="breadcrumbs-description"><?php echo e(('ru'==$cat)?'Товары достигают места назначения быстрее и надёжнее,также можете осуществлять денежные переводы в любом варианте.':''); ?> <?php echo e(('en'==$cat)?'Goods reach their destination faster and more reliably, you can also make money transfers in any way.':''); ?> <?php echo e(('tu'==$cat)?'Eşyalarınız gideceği yere daha hızlı ve güvenilir bir şekilde ulaşır, dilediğiniz şekilde para transferi de yapabilirsiniz.':''); ?>

          <br>
          <br>

        </div>
      </div>
    </div>
    <!-- Page Breadcrumbs End -->

    <!-- Main Body Content Start -->
    <main id="body-content">

      <!-- What We Offer Start -->
      <section class="wide-tb-80 bg-fixed what-we-offer">
        <div class="container pos-rel">
          <div class="row align-items-center">

            <div class="col-md-6">
              
<h2 class="mb-4 fw-7 txt-white wow fadeInLeft" data-wow-duration="0" data-wow-delay="0s">
<?php if('ru'==$cat): ?> 
Качество <span class="fw-6 txt-orange">и</span> эффективность <br><span class="fw-6 txt-orange">по достойной цены.</span>
<?php elseif('en'==$cat): ?>
Quality <span class = "fw-6 txt-orange"> and </span> efficiency <br> <span class = "fw-6 txt-orange"> by worthy of the price.</span>
<?php else: ?>               
Kalite <span class = "fw-6 txt-orange"> ve </span> verimlilik <br> <span class = "fw-6 txt-orange"> tarafından uygun fiyat. </span> <?php endif; ?>
</h2>


 <?php echo isset($pronas->cachistva[$cat])?$pronas->cachistva[$cat]:''; ?>



              




            </div>


            <div class="col-md-6">

            </div>

          </div>

        </div>
      </section>
      <!-- What We Offer End -->


      <!-- Welcome To Cargo Start -->
      <section class="bg-light-gray wide-tb-100">
        <div class="container">
          <div class="row">
            <!-- Heading Main -->
            <div class="col-sm-12 wow fadeInDown" data-wow-duration="0" data-wow-delay="0s">

              <h1 class="heading-main">
                <?php if('ru'==$cat): ?> <span>что мы предлагаем?</span>Наша основние услуги
                <?php elseif('en'==$cat): ?> <span> what do we offer? </span> Our main services
                <?php else: ?> <span> ne sunuyoruz? </span> Başlıca hizmetlerimiz <?php endif; ?>
              </h1>
            </div>
            <!-- Heading Main -->
          <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <!-- Icon Box 1 -->
            <div class="col-md-3 wow fadeInUp" data-wow-duration="0" data-wow-delay="0.<?php echo e($key); ?>s">
              <a href="<?php echo e(route('ushow',['cat'=>$cat,'uslug'=>$value->alias])); ?>">
                <div class="icon-box-1">
                  <img src="<?php echo e(asset('/uslugi/'.$value->img['min'])); ?>" alt="<?php echo e($value->title[$cat]); ?>">
                  <div class="text">
                    <?php if($key==0): ?><i class="icofont-vehicle-delivery-van"></i><?php elseif($key==1): ?><i class="icofont-airplane-alt"></i>
                    <?php else: ?><i class="icofont-ship"></i> <?php endif; ?>

                    <?php echo e($value->title[$cat]); ?>

                  </div>
                </div>
              </a>
            </div>
            <!-- Icon Box 1 -->
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



          </div>
        </div>
      </section>
      <!-- Welcome To Cargo End -->






<section class="bg-sky-blue wide-tb-100">
        <div class="container pos-rel">
          <div class="row">
            <div class="img-business-man">
              <img src="<?php echo e(asset(env('THEME').'/images/pros.jpg')); ?>" alt="What makes use unique">
            </div>

            <!-- Heading Main -->
            <div class="col-sm-12 wow fadeInDown" data-wow-duration="0" data-wow-delay="0s">
              <h1 class="heading-main">
                <?php if('ru'==$cat): ?> <span>Наша плюсы</span>ЧТО ЖЕ ДЕЛАЕТ НАС ОСОБЕННЫМИ?
                <?php elseif('en'==$cat): ?> <span> Our pros </span> WHAT MAKES US SPECIAL?
                <?php else: ?> <span> Profesyonellerimiz </span> BİZİ ÖZEL YAPAN NEDİR? <?php endif; ?>
              </h1>
            </div>
            <!-- Heading Main -->
            <div class="col-md-6 ml-auto">
              <div class="row">


                  <?php echo isset($pronas->osobiy[$cat])?$pronas->osobiy[$cat]:''; ?>



              </div>
            </div>
          </div>
        </div>
      </section>





<section class="bg-light-gray">
        <div class="container p-0">
          <div class="row align-items-center no-gutters">
           
<?php echo isset($pronas->competent[$cat])?$pronas->competent[$cat]:''; ?>


          </div>
        </div>
      </section>







<script type="text/javascript">
  
$('ul.list-unstyled.icons-listing.theme-orange.mb-0 li').append('<i class="icofont-check"></i>');
$('div.toggle').append('<i class="icofont-rounded-down"></i>');

</script><?php /**PATH /var/www/eosts/resources/views/eosts/full_uslug_content.blade.php ENDPATH**/ ?>