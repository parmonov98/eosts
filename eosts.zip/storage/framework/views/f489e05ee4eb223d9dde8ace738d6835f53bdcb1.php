<h2><u>Вопросы</u></h2>

<div id="content-page" class="content group">
				            <div class="hentry group">

<!-- summernote css/js -->
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.js"></script>




<?php echo Form::open(['url' => route('setVopraosUp') ,'class'=>'contact-form','method'=>'POST','enctype'=>'multipart/form-data']); ?>



<?php
  $i=0;
  $j=0;
  $languages=['ru'=>'Русский','en'=>'English','tu'=>'Türkçe'];
  ?>
  <div class="col-md-12">
      <ul class="nav nav-tabs">
            <?php foreach ($languages as $language => $label) { ?>
                <li class="<?= ($i==0)?'active':'' ?>"><a data-toggle="tab" href="#<?=$language?>"><?=$label?></a></li>


      <?php $i++; } ?>
        </ul>


    <div class="tab-content">

              <?php foreach ($languages as $language => $label) { ?>
               <div id="<?=$language?>" class="tab-pane fade in <?= ($j==0)?'active':'' ?>">



    <br />

    <div class="input-prepend"><span class="add-on">

<i class="icon-user"></i></span>
Вопрос:<strong style="color:red;">*</strong> <?php echo Form::text('vopros['.$language.']', old("vopros[$language]"), ['class'=>'form-control','placeholder'=>'Введите название страницы']); ?>




 </div>

      <div class="input-prepend"><span class="add-on">

      <i class="icon-user"></i></span>
    


      Отвит на <?php echo e($label); ?> :<strong style="color:red;">*</strong> 

      <?php echo Form::textarea('otvet['.$language.']', old("otvet[$language]"), ['id'=>'summernote','class' => 'form-control','placeholder'=>'Введите текст страницы']); ?>

      

       </div>




                </div>
            <?php $j++; } ?>





		<br />

	<?php echo Form::button('Сохранить', ['class' => 'btn btn-block btn-success btn-flat','type'=>'submit']); ?>


<?php echo Form::close(); ?>




<?php if(count($setname)>0): ?>
<table class="table table-striped table-bordered table-hover" style="margin-top: 30px;">
  <thead>
    <tr class="active">
      <th scope="col">#</th>
      <th scope="col">Вопрос</th>
      <th scope="col">Отвит</th>
      <th style="width: 50px;text-align: center;"><i class="fa fa-trash-o"></i></th>
    </tr>
  </thead>
  <tbody>
<?php $__currentLoopData = $setname; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$set): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e(++$k); ?></th>
      <td><?php echo $set->vopros['ru']; ?></td>
      <td><?php echo $set->otvet['ru']; ?></td>
      <td>
<?php echo Form::open(['url' => route('setVopdelUp',['id'=>$set->id]),'class'=>'form-horizontal','method'=>'POST']); ?>

<?php echo e(method_field('DELETE')); ?>

<?php echo Form::button('<i class="fa fa-trash-o"></i>', ['class' => 'btn btn-danger','type'=>'submit']); ?>

<?php echo Form::close(); ?></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </tbody>
</table>
<?php endif; ?>

</div>
</div>


<!-- summernote css/js -->
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.js"></script>
<script type="text/javascript">
    $('#summernote*').summernote({
        height: 100
    });
</script><?php /**PATH /var/www/eosts/resources/views/eosts/admin/settings/vopraos_content.blade.php ENDPATH**/ ?>