<?php
$url = $_SERVER['HTTP_HOST'];
if(!session()->has('lang')){
		session()->put('lang', 'ru');
	}
$lang = session('lang');
	?>


<!DOCTYPE HTML>
<html lang="ru-RU">
<head>
  <title><?php echo e(isset($title)?$title:''); ?></title>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compitable" content="IE=egde">
 <meta name="viewport" content="width=device-width, initial-scale=1.0 user-scalable=no" />
  <meta name="author" content="<?php echo e((isset($author)) ? $author : ''); ?>">

        <!-- <link rel="canonical" href="http://example.com/" /> -->
<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset(env('THEME').'/images/favicon.ico')); ?>">
<meta name="robots" content="index, follow">


  <meta name="viewport" content="width=480">
  <link rel="alternate" type="application/atom+xml" title="News" href="/feed">
  <meta name="description" content="<?php echo e((isset($meta_desc)) ? $meta_desc : ''); ?>">
  <meta name="keywords" content="<?php echo e((isset($keywords)) ? $keywords : ''); ?>">
  <meta name="votdel" content="<?php echo e((isset($votdel)) ? $votdel : ''); ?>">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <?php echo Html::style(env('THEME').'/css/base.css'); ?>

	<?php echo Html::style(env('THEME').'/css/icofont.min.css'); ?>

	<?php echo Html::style(env('THEME').'/css/font-awesome.min.css'); ?>


	<?php echo Html::style(env('THEME').'/css/tiny-slider.css'); ?>


		<?php echo Html::script(env('THEME').'/js/jquery-3.5.1.min.js'); ?>


    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

        <!-- <link rel="stylesheet" type="text/css" href="rev-slider/revolution/css/settings.css"> -->
        <!-- <link rel="stylesheet" type="text/css" href="rev-slider/revolution/css/layers.css"> -->
  
        
</head>



<body itemscope itemtype="https://schema.org/WebPage">





        <header class="top-border top-transparent header-logo-top">
            <div class="top-bar-right d-flex align-items-center text-md-left">
                <div class="container">
                    <div class="row align-items-center ">
                        <div class="col-12 pr-sm-0 " itemscope itemtype="https://schema.org/Person">

                            <div class="d-flex justify-content-between py-2 ">
                                <div class="top-text" itemprop="location" itemscope itemtype="https://schema.org/Place">
        <small class="txt-ligt-gray"><?php echo e(('ru'==$lang)?'Адрес':''); ?><?php echo e(('en'==$lang)?'Address':''); ?><?php echo e(('tu'==$lang)?'Address':''); ?></small>
                         <?php if(isset($getsetting) && $getsetting['address']['addres']['tosh'][$lang]!=null): ?>
                          <span class="fw-7 txt-blue" itemprop="address"><?php echo $getsetting['address']['addres']['tosh'][$lang]; ?></span>
                          <?php endif; ?>                                    





                           


                                </div>
                                <div class="top-text">
                                    <small class="txt-ligt-gray"><?php echo e(('ru'==$lang)?'Эл.почта':''); ?><?php echo e(('en'==$lang)?'E-mail':''); ?><?php echo e(('tu'==$lang)?'E-mail':''); ?></small>
                                    <span class="fw-6 txt-blue">
                                    <?php if(isset($getsetting) && $getsetting['address']['email'][0]!=null): ?>
                                        <a href="mailto:<?php echo e($getsetting['address']['email'][0]); ?>" itemprop="email"
                                            class="txt-blue"><?php echo e($getsetting['address']['email'][0]); ?></a>
                                    <?php endif; ?>
                                        
                                        <br />
                                    <?php if(isset($getsetting) && $getsetting['address']['email'][1]!=null): ?>
                                        <a href="mailto:<?php echo e($getsetting['address']['email'][1]); ?>" itemprop="email"
                                            class="txt-blue"><?php echo e($getsetting['address']['email'][1]); ?></a>
                                    <?php endif; ?>
                                    </span>
                                </div>
                                <div class="top-text">
                                    <small class="txt-ligt-gray"><?php echo e(('ru'==$lang)?'Телефон':''); ?>

                        <?php echo e(('en'==$lang)?'Telephone':''); ?>  <?php echo e(('tu'==$lang)?'Telefon':''); ?></small>
                             <?php if(isset($getsetting) && $getsetting['address']['phone'][0]!=null): ?>
                                    <span class="fw-7 txt-blue" itemprop="telephone"><?php echo e($getsetting['address']['phone'][0]); ?></span>
                              <?php endif; ?>


                                    <br />
                             <?php if(isset($getsetting) && $getsetting['address']['phone'][1]!=null): ?>
                                    <span class="fw-7 txt-blue" itemprop="telephone"><?php echo e($getsetting['address']['phone'][1]); ?></span>
                              <?php endif; ?>
                                </div>

                                <!-- Topbar Language Dropdown Start -->
                                <div class="dropdown d-inline-flex lang-toggle shadow-sm order-lg-last justify-center align-items-center">


<?php if('ru'==$lang): ?>
<a href="/ru" class="dropdown-toggle btn" data-toggle="dropdown" aria-haspopup="true"
    aria-expanded="false" data-hover="dropdown" data-animations="slideInUp slideInUp slideInUp slideInUp">
<img src="<?php echo e(asset(env('THEME').'/images/ru.svg')); ?>" alt="" class="dropdown-item-icon"><span class="d-inline-block d-lg-none">Ru</span> <span class="d-none d-lg-inline-block">Русский</span> <i class="icofont-rounded-down"></i></a>
<?php elseif('en'==$lang): ?>
<a href="/en" class="dropdown-toggle btn" data-toggle="dropdown" aria-haspopup="true"
    aria-expanded="false" data-hover="dropdown" data-animations="slideInUp slideInUp slideInUp slideInUp">
<img src="<?php echo e(asset(env('THEME').'/images/us.svg')); ?>" alt="" class="dropdown-item-icon"><span class="d-inline-block d-lg-none">Ru</span> <span class="d-none d-lg-inline-block">English</span> <i class="icofont-rounded-down"></i></a>

<?php else: ?>
<a href="#" class="dropdown-toggle btn" data-toggle="dropdown" aria-haspopup="true"
    aria-expanded="false" data-hover="dropdown" data-animations="slideInUp slideInUp slideInUp slideInUp">
<img src="<?php echo e(asset(env('THEME').'/images/tr.svg')); ?>" alt="" class="dropdown-item-icon"><span class="d-inline-block d-lg-none">Tu</span> <span class="d-none d-lg-inline-block">Türkçe</span> <i class="icofont-rounded-down"></i></a>
<?php endif; ?>



                                    <div class="dropdown-menu dropdownhover-bottom dropdown-menu-right" role="menu">
                                <?php if('ru'!=$lang): ?>
                                        <a class="dropdown-item" href="/ru" itemprop="availableLanguage" itemscope
                                            itemtype="https://schema.org/Language">
                                            <img src="<?php echo e(asset(env('THEME').'/images/ru.svg')); ?>" alt="" class="dropdown-item-icon">
                                            <span itemprop="name">
                                                Русский
                                            </span>
                                        </a>
                                    <?php endif; ?>
                                 <?php if('en'!=$lang): ?>
                                        <a class="dropdown-item" href="/en" itemprop="availableLanguage" itemscope
                                            itemtype="https://schema.org/Language">
                                            <img src="<?php echo e(asset(env('THEME').'/images/us.svg')); ?>" alt="" class="dropdown-item-icon">
                                            <span itemprop="name">
                                                English
                                            </span>
                                        </a>
                                <?php endif; ?>
                                 <?php if('tu'!=$lang): ?>

                                      <!--   <a class="dropdown-item" href="#" itemprop="availableLanguage" itemscope
                                            itemtype="https://schema.org/Language">
                                            <img src="<?php echo e(asset(env('THEME').'/images/tr.svg')); ?>" alt="" class="dropdown-item-icon">
                                            <span itemprop="name">
                                                Türkçe
                                            </span>
                                        </a> -->
                                <?php endif; ?>

                                    </div>
                                </div>
                                <!-- Topbar Language Dropdown End -->

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <nav class="navbar navbar-expand-lg bg-transparent header-fullpage">
                <div class="container text-nowrap bdr-nav px-0">

                    <a class="navbar-brand" href="/" itemscope itemtype="https://schema.org/LocalBusiness">
                        <img src="<?php echo e(asset(env('THEME').'/images/logo.png')); ?>" alt="Компания EOSTS(EvroOsiyo Sarbon Trans Servis)" itemprop="logo">
                    </a>

                    <span class="order-lg-last d-inline-flex request-btn d-lg-none">
                        <!-- <a id="search_home" class="nav-link mr-2 ml-auto" href="#"><i class="icofont-search"></i></a> -->
                        <a class="navbar-brand-mobile" href="index.html">
                            <img src="<?php echo e(asset(env('THEME').'/images/logo.png')); ?>" alt="Компания EOSTS(EvroOsiyo Sarbon Trans Servis)"
                                itemprop="logo">
                        </a>
                    </span>


                    <div class="d-inline-flex request-btn ml-2 order-lg-last">
                        <a class="btn-theme icon-left bg-orange no-shadow d-none d-lg-inline-block align-self-center"
                            href="#" role="button" data-toggle="modal" data-target="#request_popup"><i
                                class="icofont-page"></i>
                           <?php echo e(('ru'==$lang)?'Получить расчёт':''); ?><?php echo e(('en'==$lang)?'Get a quote':''); ?><?php echo e(('tu'==$lang)?'Fiyat teklifi al':''); ?> 
                        </a>
                    </div>
                    <!-- Topbar Request Quote Start -->

                    <!-- Toggle Button Start -->
                    <button class="navbar-toggler x collapsed" type="button" data-toggle="collapse"
                        data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false"
                        aria-label="Toggle navigation">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <!-- Toggle Button End -->

                    <!-- Topbar Request Quote End -->

                    <div class="collapse navbar-collapse mr-5" id="navbarCollapse" data-hover="dropdown"
                        data-animations="slideInUp slideInUp slideInUp slideInUp" itemscope=""
                        itemtype="http://schema.org/SiteNavigationElement">

<?php echo $__env->yieldContent('navigation'); ?>                 

                        <!-- Main Navigation End -->
                        <div class="dropdown d-inline-flex mobile-lang-toggle shadow-sm d-lg-none">





<?php if('ru'==$lang): ?>
    <a href="#" class="dropdown-toggle btn ml-auto" data-toggle="dropdown" aria-haspopup="true"
        aria-expanded="false" data-hover="dropdown" data-animations="slideInUp"
        itemprop="availableLanguage" itemscope itemtype="https://schema.org/Language">
        <img src="<?php echo e(asset(env('THEME').'/images/ru.svg')); ?>" alt="" class="dropdown-item-icon">
        <span class="d-inline-block d-lg-none">Ru</span>
        <span class="d-none d-lg-inline-block" itemprop="name">Русский</span>
    </a>
<?php elseif('en'==$lang): ?>
    <a href="#" class="dropdown-toggle btn ml-auto" data-toggle="dropdown" aria-haspopup="true"
        aria-expanded="false" data-hover="dropdown" data-animations="slideInUp"
        itemprop="availableLanguage" itemscope itemtype="https://schema.org/Language">
        <img src="<?php echo e(asset(env('THEME').'/images/us.svg')); ?>" alt="" class="dropdown-item-icon">
        <span class="d-inline-block d-lg-none">En</span>
        <span class="d-none d-lg-inline-block" itemprop="name">English</span>
    </a>
<?php else: ?>
<!--     <a href="#" class="dropdown-toggle btn ml-auto" data-toggle="dropdown" aria-haspopup="true"
        aria-expanded="false" data-hover="dropdown" data-animations="slideInUp"
        itemprop="availableLanguage" itemscope itemtype="https://schema.org/Language">
        <img src="<?php echo e(asset(env('THEME').'/images/tr.svg')); ?>" alt="" class="dropdown-item-icon">
        <span class="d-inline-block d-lg-none">Tu</span>
        <span class="d-none d-lg-inline-block" itemprop="name">Türkçe</span>
    </a>
 -->
<?php endif; ?>





                            <div class="dropdown-menu dropdownhover-bottom dropdown-menu-left" role="menu">


<?php if('ru'!=$lang): ?>                 
<a class="dropdown-item active" href="/ru" itemprop="availableLanguage" itemscope
    itemtype="https://schema.org/Language">
    <img src="<?php echo e(asset(env('THEME').'/images/ru.svg')); ?>" alt="" class="dropdown-item-icon">
    <span itemprop="name">
        Русский
    </span>
</a>
<?php endif; ?>
<?php if('en'!=$lang): ?>
<a class="dropdown-item " href="/en" itemprop="availableLanguage" itemscope
    itemtype="https://schema.org/Language">
    <img src="<?php echo e(asset(env('THEME').'/images/us.svg')); ?>" alt="" class="dropdown-item-icon">
    <span itemprop="name">
        English
    </span>
</a>
<?php endif; ?>
 <?php if('tu'!=$lang): ?>
<!-- <a class="dropdown-item " href="#" itemprop="availableLanguage" itemscope
    itemtype="https://schema.org/Language">
    <img src="<?php echo e(asset(env('THEME').'/images/tr.svg')); ?>" alt="" class="dropdown-item-icon">
    <span itemprop="name">
        Türkçe
    </span>
</a> -->
<?php endif; ?>









                            </div>
                        </div>


                    </div>


                </div>
            </nav>


        </header>


<?php echo $__env->yieldContent('slider'); ?>

<?php echo $__env->yieldContent('content'); ?>  


        <!-- Main Body Content Start -->
        <main id="body-content" style="overflow-y: inherit;">

<?php echo $__env->yieldContent('ind'); ?>            
<?php echo $__env->yieldContent('special'); ?> 

<?php echo $__env->yieldContent('features'); ?> 
<?php echo $__env->yieldContent('quote'); ?> 
<?php echo $__env->yieldContent('counter'); ?> 
<?php echo $__env->yieldContent('reviews'); ?> 
<?php echo $__env->yieldContent('otzivi'); ?> 
<?php echo $__env->yieldContent('clients'); ?> 
            
<?php echo $__env->yieldContent('vopros'); ?> 


<?php echo $__env->yieldContent('gallery'); ?> 

<?php echo $__env->yieldContent('callout'); ?> 

 



 
            <!-- Google Map Start -->
            <!-- <section class="map-bg">
            <div class="contact-details row d-flex">
                <div class="col">
                    <h4>Бухара</h4>
                    <p><i class="icofont-phone"></i> +99899 311 49 00</p>
                    <div class="text-nowrap"><i class="icofont-email"></i> <a href="#">info@sarbontrans.com</a></div>
                </div>
                <div class="col">
                    <h4>Ташкент</h4>
                    <p><i class="icofont-phone"></i> +998 99 0999559</p>
                    <div class="text-nowrap"><i class="icofont-email"></i> <a href="#">info@sarbontrans.com</a></div>
                </div>
            </div>
            <div id="map-holder" class="pos-rel">
                <div id="map_extended">
                    <p>This will be replaced with the Google Map.</p>
                </div>
            </div>
            Google Map Start 
            </section>-->

        </main>


        <!-- Main Footer Start -->
        <footer class="wide-tb-70 bg-light-gray pb-0">
            <div class="container ">
                <div class="row">

                    <!-- Column First -->
                    <div class="col-lg-4 col-md-6">
                        <div class="logo-footer">
                            <img src="<?php echo e(asset(env('THEME').'/images/logo_footer.png')); ?>" alt="" />
                        </div>
                        <p>
                            <?php echo ('ru'==$lang)?'Компания EOSTS(EvroOsiyo Sarbon Trans Servis) занимается доставкой грузов из Узбекистана, Турции, России, Украины, Польши, Литвы, Латвии и стран Европы. Мы работаем с более чем 200 партнерами и сотрудничаем более 10 лет. <br />Наша работа просто классная!':''; ?>


                             <?php echo ('en'==$lang)?'EOSTS (Evro Osiyo Sarbon Trans Servis) delivers goods from Uzbekistan, Turkey, Russia, Ukraine, Poland, Lithuania, Latvia and European countries. We work with more than 200 partners and have been cooperating for over 10 years. <br /> Our work is just awesome!':''; ?>


                            <?php echo ('tu'==$lang)?'EOSTS (Evro Osiyo Sarbon Trans Servis) Özbekistan, Türkiye, Rusya, Ukrayna, Polonya, Litvanya, Letonya ve Avrupa ülkelerinden mal sevkiyatı yapmaktadır. 200\'den fazla ortakla çalışıyoruz ve 10 yılı aşkın bir süredir işbirliği yapıyoruz. <br /> İşimiz harika!':''; ?>


                            
                        </p>

                        <h3 class="footer-heading"><?php echo e(('ru'==$lang)?'Наши соц.сети':''); ?>

                        <?php echo e(('en'==$lang)?'Our social networks':''); ?>

                    <?php echo e(('tu'==$lang)?'Sosyal ağlarımız':''); ?></h3>
                        <div class="social-icons">



















<?php if(isset($getsetting) && isset($getsetting['sot_network']['sotnet']['facebook'])): ?>
<a href="<?php echo e($getsetting['sot_network']['sotnet']['facebook']); ?>" target="_blank"><i class="icofont-facebook"></i></a>
<?php endif; ?>

<?php if(isset($getsetting) && isset($getsetting['sot_network']['sotnet']['telegram'])): ?>
<a href="<?php echo e($getsetting['sot_network']['sotnet']['telegram']); ?>" target="_blank"><i class="icofont-telegram"></i></a>
<?php endif; ?>


 <?php if(isset($getsetting) && isset($getsetting['sot_network']['sotnet']['whatsapp'])): ?>
<a href="<?php echo e($getsetting['sot_network']['sotnet']['whatsapp']); ?>" target="_blank"><i class="icofont-whatsapp"></i></a>
 <?php endif; ?>

 
<?php if(isset($getsetting) && isset($getsetting['sot_network']['sotnet']['instagram'])): ?>
<a href="<?php echo e($getsetting['sot_network']['sotnet']['instagram']); ?>" target="_blank"><i class="icofont-instagram"></i></a>
<?php endif; ?>

<?php if(isset($getsetting) && isset($getsetting['sot_network']['sotnet']['twitter'])): ?>
<a href="<?php echo e($getsetting['sot_network']['sotnet']['twitter']); ?>" target="_blank"><i class="icofont-twitter"></i></a>
<?php endif; ?>

<?php if(isset($getsetting) && isset($getsetting['sot_network']['sotnet']['youtube'])): ?>
<a href="<?php echo e($getsetting['sot_network']['sotnet']['youtube']); ?>" target="_blank"><i class="icofont-youtube"></i></a>
<?php endif; ?>

                        </div>
                    </div>
                    <!-- Column First -->

                    <!-- Column Second -->
                    <div class="col-lg-4 col-md-6">
                        <h3 class="footer-heading"> <?php echo e(('ru'==$lang)?'Карта сайта':''); ?> <?php echo e(('en'==$lang)?'Map of site':''); ?> <?php echo e(('tu'==$lang)?'Site haritası':''); ?>  </h3>
                        <div class="footer-widget-menu">
                            <ul class="list-unstyled">



<?php echo $__env->yieldContent('futnav'); ?> 


                            </ul>
                        </div>
                    </div>
                    <!-- Column Second -->

                    <!-- Column Third -->
                    <div class="col-lg-4 col-md-6">
                        <h3 class="footer-heading"> <?php echo e(('ru'==$lang)?'Наши контакты':''); ?><?php echo e(('en'==$lang)?'Our contacts':''); ?><?php echo e(('tu'==$lang)?'Our contacts':''); ?></h3>
                        <div class="footer-widget-contact">
                            <div class="media mb-3">
                                <i class="icofont-google-map mr-3"></i>
                                <div class="media-body" itemprop="location" itemscope=""
                                    itemtype="https://schema.org/Place">

                         <?php if(isset($getsetting) && $getsetting['address']['addres']['tosh'][$lang]!=null): ?>
                          <span itemprop="address"><?php echo $getsetting['address']['addres']['tosh'][$lang]; ?></span>
                          <?php endif; ?>  
                                    <span itemprop="address" itemscope="" itemtype="https://schema.org/PostalAddress">
                                </div>
                            </div>
                            <div class="media mb-2">
                                <i class="icofont-smart-phone mr-3"></i>
                                <div class="media-body">

                             <?php if(isset($getsetting) && $getsetting['address']['phone'][0]!=null): ?>
                                    <div itemprop="telephone">
                                        <a href="tel:<?php echo e($getsetting['address']['phone'][0]); ?>"><?php echo e($getsetting['address']['phone'][0]); ?></a>
                                    </div>
                              <?php endif; ?>

                             <?php if(isset($getsetting) && $getsetting['address']['phone'][1]!=null): ?>
                                    <div itemprop="telephone">
                                        <a href="tel:<?php echo e($getsetting['address']['phone'][1]); ?>"><?php echo e($getsetting['address']['phone'][1]); ?></a>
                                    </div>
                              <?php endif; ?>

                                </div>
                            </div>
                            <div class="media mb-3">
                                <i class="icofont-ui-email mr-3"></i>
                                <div class="media-body">

                                    <?php if(isset($getsetting) && $getsetting['address']['email'][0]!=null): ?>
                                    <div class="pt-1"><a href="mailto:<?php echo e($getsetting['address']['email'][0]); ?>"><?php echo e($getsetting['address']['email'][0]); ?></a></div>
                                    <?php endif; ?>
                                        
                                    <?php if(isset($getsetting) && $getsetting['address']['email'][1]!=null): ?>
                                     <div class="pt-1"><a href="mailto:<?php echo e($getsetting['address']['email'][1]); ?>"><?php echo e($getsetting['address']['email'][1]); ?></a></div>
                                    <?php endif; ?>


                                </div>
                            </div>
                            <div class="media mb-3">
                                <i class="icofont-clock-time mr-3"></i>
                                <div class="media-body">
                                    <!-- <div><strong>Пон - Вос</strong></div> -->
                                    <div class="pt-1">
                                        <?php echo e(('ru'==$lang)?'24/7 Служба поддержки клиентов':''); ?><?php echo e(('en'==$lang)?'24/7 Product support serviceses client':''); ?><?php echo e(('tu'==$lang)?'24/7 Product support serviceses client':''); ?>

                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                </div>
            </div>

            <div class="copyright-wrap bg-navy-blue wide-tb-30">
                <div class="container">
                    <div class="row text-md-left text-center">
                        <div class="col-sm-12 col-md-6 copyright-links">
                            <strong>&copy; EOSTS - <?php echo e(date("Y")); ?>. </strong><?php echo e(('ru'==$lang)?'Все права защищены.':''); ?> <?php echo e(('en'==$lang)?'All right are protected.':''); ?> <?php echo e(('tu'==$lang)?'All right are protected.':''); ?>

                        </div>
                        <div class="col-sm-12 col-md-6 text-md-right text-center">
                          <?php echo e(('ru'==$lang)?'Разработчик:':''); ?> <?php echo e(('en'==$lang)?'The Developer:':''); ?> <?php echo e(('tu'==$lang)?'The Developer:':''); ?>  
                            <a href="https://parmonov98.uz" target="_blank" rel="nofollow">@parmonov98</a>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Main Footer End -->

        <!-- Search Popup Start -->
        <div class="overlay overlay-hugeinc">
            <form class="form-inline mt-2 mt-md-0">
                <div class="form-inner">
                    <div class="form-inner-div d-inline-flex align-items-center no-gutters">
                        <div class="col-md-1">
                            <i class="icofont-search"></i>
                        </div>
                        <div class="col-10">
                            <input class="form-control w-100 p-0" type="text" placeholder="Search" aria-label="Search">
                        </div>
                        <div class="col-md-1">
                            <a href="#" class="overlay-close link-oragne"><i class="icofont-close-line"></i></a>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <!-- Search Popup End -->













        <!-- Request Modal -->
        <div class="modal fade" id=request_popup tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered request_popup" role="document">
                <div class="modal-content">
                    <div class="modal-body p-0">
                        <!-- Contact Details Start -->
                        <section class="pos-rel bg-light-gray">
                            <div class="container-fluid p-0">
                                <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                                    <i class="icofont-close-line"></i>
                                </a>
                                <div class="d-lg-flex no-gutters mb-spacer-md"
                                    style="box-shadow: 0px 18px 76px 0px rgba(0, 0, 0, 0.06);">
                        

                                    <div class="col-md-12 col-12">
                                        <div class="px-3 m-5">
                                            <h1 class="heading-main mb-4">
                                   <?php if('ru'==$lang): ?> <span>Оставить</span> Запрос <?php elseif('en'==$lang): ?><span> Submit </span> Request <?php else: ?>  <span> Gönder </span> İstek <?php endif; ?>
                                </h1>

<div class="alert alert-danger alert-dismissible fade " id="alertdanger" role="alert">
    
</div>

<?php if($error = Session::get('error')): ?>
    <div class="alert alert-danger">
    <button class="close" data-dismiss="alert">×</button>
    <strong><?php echo e($error); ?></strong>
    </div>
  <?php endif; ?>
  <?php if($errors = Session::get('errors')): ?>
    <div class="alert alert-danger">
    <button class="close" data-dismiss="alert">×</button>
    <ol>
    <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($error); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol></div>
  <?php endif; ?>
  <?php if($success = Session::get('success')): ?>
    <div class="alert alert-primary">
    <button class="close" data-dismiss="alert">×</button>
    <strong><?php echo e($success); ?></strong>
    </div>
  <?php endif; ?>

 <?php 
$nam = ['ru'=>'Имя','en'=>'Name','tu'=>'İsim']; $phon = ['ru'=>'Телефон номер','en'=>'Phone number','tu'=>'Telefon numarası'];
$mail = ['ru'=>'Э-почта','en'=>'Email','tu'=>'E-posta']; $texa = ['ru'=>'Опишите откуда и куда...','en'=>'Describe where and where ...','tu'=>'Nerede ve nerede olduğunu açıklayın ...']; $butt = ['ru'=>'Отправить','en'=>'Send','tu'=>'Göndermek'];

$uslug = ['ru'=>'Тип услуги','en'=>'Service type','tu'=>'Servis tipi'];
$uslug1 = ['ru'=>'Перевозка драгоценных грузов','en'=>'Transportation of precious cargo','tu'=>'Değerli kargo taşımacılığı'];
$uslug2 = ['ru'=>'Перевозка требующий особых условий хранения','en'=>'Transportation requiring special storage conditions','tu'=>'Özel saklama koşulları gerektiren taşıma'];
$uslug3 = ['ru'=>'Перевозка сверхтяжёлые грузы','en'=>'Extra heavy cargo transportation','tu'=>'Ekstra ağır yük taşımacılığı'];
$uslug4 = ['ru'=>'Страхование грузоперевозки','en'=>'Cargo insurance','tu'=>'Kargo sigortası'];
  ?>
        
<form novalidate="novalidate" class="rounded-field"><?php echo csrf_field(); ?>


<div class="form-row mb-4">
        <input type="text" name="name" id="name" class="form-control" placeholder="<?php echo e($nam[$lang]); ?>" required>
    </div>
    <div class="form-row mb-4">
        <input type="text" name="phone" id="phone" onkeypress='return event.charCode >= 48 && event.charCode <= 57' class="form-control" placeholder="<?php echo e($phon[$lang]); ?>" required>
    </div>
    <div class="form-row mb-4">
        <input type="email" name="email" id="email" class="form-control" placeholder="<?php echo e($mail[$lang]); ?>" required>
    </div>

    <div class="form-row mb-4">
        <select title="Please choose a package" required="required" id="package" name="package" class="custom-select" aria-required="true" aria-invalid="false">
            <option value=""><?php echo e($uslug[$lang]); ?></option>
            <option value="Перевозка драгоценных грузов"><?php echo e($uslug1[$lang]); ?></option>
            <option value="Перевозка требующий особых условий хранения"><?php echo e($uslug2[$lang]); ?></option>
            <option value="Перевозка сверхтяжёлые грузы"><?php echo e($uslug3[$lang]); ?></option>
            <option value="Страхование грузоперевозки"><?php echo e($uslug4[$lang]); ?></option>
        </select>
    </div>
    <div class="form-row mb-4">

    <textarea rows="7" maxlength="250" id="message" required name="message" placeholder="<?php echo e($texa[$lang]); ?>" class="form-control"></textarea>
    </div>
    <div class="form-row text-center">
        <button type="submit" id="formSubmit" class="form-btn mx-auto btn-theme bg-orange"><?php echo e($butt[$lang]); ?><i class="icofont-rounded-right"></i></button>
    </div>


                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <!-- Contact Details End -->
                    </div>
                </div>
            </div>
        </div>
        <!-- Request Modal -->




<!-- Modal -->
<div class="modal fade" id="success" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document" style="padding-left: 107px; padding-right: 107px;top: 15vh;">
    <div class="modal-content" style="background-color: #28a745;">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="
    text-align: right; padding: 8px;">
          <i class="icofont-close-line"></i>
        </button>
      <div class="modal-body" style="padding: 0;">
        <img src="/success.jpg" width="100%">
      </div>
    </div>
  </div>
</div>











    <script>
        $(document).ready(function(){
            $('#formSubmit').click(function(e){
                e.preventDefault();
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                    }
                });
                $.ajax({
                    url: "<?php echo e(route('message')); ?>",
                    method: 'post',
                    data: {"_token":$('meta[name="csrf-token"]').attr('content'),name: $('#name').val(),package: $('#package').val(), 
                    email: $('#email').val(), phone: $('#phone').val(), message: $('#message').val()
                    },
                    success: function(result){
                        console.log(result['error']);
                        if(result.errors)
                        {
                            $('#alertdanger').html(' ');


                            $.each(result.errors, function(key, value){
                                $('#alertdanger').addClass('show');
                                $('#alertdanger').append('<li>'+value+'</li>');
                            });
                        }
                        else
                        {
                            $('#alertdanger').hide();
                            $('#request_popup').modal('hide');
                            $('#success').modal('show');
                            // setTimeout(function(){ $('#success').modal('hide'); }, 1900); 

                        }
                    }
                });
            });
        });
    </script>












        <!-- Back To Top Start -->
        <a id="mkdf-back-to-top" href="#" class="off"><i class="icofont-rounded-up"></i></a>
        <!-- Back To Top End -->

        <!-- Main JavaScript -->

        <?php echo Html::script(env('THEME').'/js/popper.min.js'); ?>

        <?php echo Html::script(env('THEME').'/js/bootstrap.min.js'); ?>

        <?php echo Html::script(env('THEME').'/js/bootstrap-dropdownhover.min.js'); ?>

        <?php echo Html::script(env('THEME').'/js/jquery.cubeportfolio.min.js'); ?>



        <script>
          $(document).ready(function(){   

function addScript(src){
    var script = document.createElement('script');
    script.src = src;
    script.defer = false;
    document.body.append(script);
}                   

addScript("<?php echo asset(env('THEME').'/js/owl.carousel.min.js'); ?>");
addScript("<?php echo asset(env('THEME').'/js/jquery.waypoints.min.js'); ?>");
addScript("<?php echo asset(env('THEME').'/js/jquery.counterup.min.js'); ?>");
addScript("<?php echo asset(env('THEME').'/js/tiny-slider.js'); ?>");



addScript("<?php echo asset(env('THEME').'/js/tiny-slider.js'); ?>");
addScript("<?php echo asset(env('THEME').'/js/site-custom.js'); ?>");
addScript("<?php echo asset(env('THEME').'/js/main.js'); ?>");

});
        





        </script>









</body>
</html><?php /**PATH /var/www/eosts/resources/views/eosts/layouts/site.blade.php ENDPATH**/ ?>