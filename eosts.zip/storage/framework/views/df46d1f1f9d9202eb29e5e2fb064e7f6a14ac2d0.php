
	<div id="content-page" class="content group">
				            <div class="hentry group">
										 <?php echo Html::link(route('gallery.create'),'+',['class' => 'btn btn-primary btn-lg','style'=>'margin-bottom: 5px;']); ?>

				               <strong style="font-size: 2rem; padding: 10px; " align="right"> Fotogalereya </strong>
    <?php if($status = Session::get('status')): ?>
	<div class="alert alert-success">
	<button class="close" data-dismiss="alert">×</button>
	<strong><?php echo e($status); ?></strong>
	</div>									
    <?php endif; ?>
    <?php if($error = Session::get('error')): ?>
	<div class="alert alert-danger">
	<button class="close" data-dismiss="alert">×</button>
	<strong><?php echo e($error); ?></strong>
	</div>									
    <?php endif; ?>


				        <div class="short-table white">




<?php if($gallerys): ?>
<div class="card-body">
                <div class="row">
<?php $__currentLoopData = $gallerys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="col-sm-2" style=" padding-bottom: 5px;">
 <?php if(isset($file->img)): ?>
 <a href="<?php echo e(route('gallery.edit',['gallery'=>$file->id])); ?>">
		<div style="position: relative; width: 100%; height: 150px;  overflow: auto; border-radius: 4px 4px 0px 0px;" >
			<img src="<?php echo e(asset('/gallery/'.$file->img['min'])); ?>">


		</div></a>
<?php endif; ?>

<?php echo Form::open(['url' => route('gallery.destroy',['gallery'=>$file->id]),'class'=>'form-horizontal','method'=>'POST']); ?>

	    <?php echo e(method_field('DELETE')); ?>

	    <?php echo Form::button('<i class="fa fa-trash-o"></i>', ['class' => 'btn btn-danger btn-block','style'=>'border-radius: 0px 0px 4px 4px;','type'=>'submit']); ?>

	<?php echo Form::close(); ?>

                  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <?php endif; ?>

<style type="text/css">
	img{
		float: left;
    width: 100%;
    height: 100%;
    object-fit: contain;
	}
</style>




 </div> </div>








				             <div class="wrap_result"></div>


				            <!-- START COMMENTS -->
				            <div id="comments">



				            </div>
				            <div class="wrap_result"></div>
				          <?php if($gallerys): ?>
				          <div class="pagination" align="center">
				             <?php echo e($gallerys->links()); ?>

				            <!-- END COMMENTS -->
				            </div>
				          <?php endif; ?>

 </div>


<?php /**PATH /var/www/eosts/resources/views/eosts/admin/gallery/gallerys_content.blade.php ENDPATH**/ ?>