
	<div id="content-page" class="content group">
				            <div class="hentry group">
	<p>	<strong style="font-size: 2.5rem; padding: 10px; " align="right"> Наши клиенты </strong>
		</p>
    <?php if($status = Session::get('status')): ?>
	<div class="alert alert-success">
	<button class="close" data-dismiss="alert">×</button>
	<strong><?php echo e($status); ?></strong>
	</div>									
    <?php endif; ?>
    <?php if($error = Session::get('error')): ?>
	<div class="alert alert-danger">
	<button class="close" data-dismiss="alert">×</button>
	<strong><?php echo e($error); ?></strong>
	</div>									
    <?php endif; ?>


				        <div class="short-table white">

<?php echo Form::open(['url' => route('setNakilSav') ,'class'=>'contact-form','method'=>'POST','enctype'=>'multipart/form-data']); ?>


<div class="row">
  <div class="col-md-6">Названия: <input type="text" class="form-control" name="name" id=""></div>
  <div class="col-md-6"><input type="file" name="file" id="file" size="2048">

Размер <strong> 2 МБ</strong> (в формате <strong>.png, .gif, .jpeg, .jpg </strong>) файл можно отправить  
</div>
</div>



</div>

		</div>

		<br />

	

	<?php echo Form::button('Сохранить', ['class' => 'btn btn-block btn-success btn-flat','type'=>'submit']); ?>


<?php echo Form::close(); ?>
















<?php if($setname): ?>
<div class="card-body">
                <div class="row">
<?php $__currentLoopData = $setname; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="col-sm-2" style=" padding-bottom: 5px;">
                  <?php if(isset($file->img)): ?>
				<?php echo e(Html::image(asset('/nakil/'.$file->img),'',['style'=>'width:100%;'])); ?>

													<?php endif; ?>
<?php echo Form::open(['url' => route('setNakildel',['id'=>$file->id]),'class'=>'form-horizontal','method'=>'POST']); ?>

	    <?php echo e(method_field('DELETE')); ?>

	    <?php echo Form::button('<i class="fa fa-trash-o"></i>', ['class' => 'btn btn-danger btn-block','type'=>'submit']); ?>

	<?php echo Form::close(); ?>

                  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <?php endif; ?>






 </div> </div>








				             <div class="wrap_result"></div>


				            <!-- START COMMENTS -->
				            <div id="comments">



				            </div>
				            <div class="wrap_result"></div>
				          <?php if($setname): ?>
				          <div class="pagination" align="center">
				             <?php echo e($setname->links()); ?>

				            <!-- END COMMENTS -->
				            </div>
				          <?php endif; ?>

 </div>


<?php /**PATH /var/www/eosts/resources/views/eosts/admin/settings/nakils_content.blade.php ENDPATH**/ ?>