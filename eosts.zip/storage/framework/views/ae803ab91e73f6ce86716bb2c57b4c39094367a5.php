
	<div id="content-page" class="content group">
				            <div class="hentry group">
										 <?php echo Html::link(route('slider.create'),'+',['class' => 'btn btn-primary btn-lg ']); ?>

				                <h2>Slaydlar uchun rasm  </h2>
				        <div class="short-table white">


                            <div class="tournamentsTable">
<?php if($sliders): ?>
				                    <table class="table table-striped" style="width: 100%" cellspacing="0" cellpadding="0">
				                        <thead>
				                            <tr>
				                                
				                                <th style="width: 50px;text-align: center;">ID</th>
				                                <th>Sarlavha</th>
				                                <th style="width: 100px;text-align: center;">Surat</th>
				                                <th style="width: 50px;text-align: center;"><i class="fa fa-pencil-square-o"></i></th>
				                                <th style="width: 50px;text-align: center;"><i class="fa fa-trash-o"></i></th>
				                            </tr>
				                        </thead>
				                        <tbody>
											<?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr>
				                                <td class="align-left"><?php echo e($file->id); ?></td>
				                                <td class="align-left">

				                                <?php echo e($file->name['name']['ru']); ?>


				                               </td>



				                                <td>
													<?php if(isset($file->img)): ?>
				<?php echo e(Html::image(asset('/sliders/'.$file->img['min']),'',['style'=>'width:50px;'])); ?>

													<?php endif; ?>
												</td>

</td>
													<td>
														<a href="<?php echo e(route('slider.edit',['slider'=>$file->id])); ?>" class="btn btn-success"><i class="fa fa-pencil-square-o"></i></a>
													</td>


				                                <td>
				                                	

												<?php echo Form::open(['url' => route('slider.destroy',['slider'=>$file->id]),'class'=>'form-horizontal','method'=>'POST']); ?>

												    <?php echo e(method_field('DELETE')); ?>

												    <?php echo Form::button('<i class="fa fa-trash-o"></i>', ['class' => 'btn btn-danger','type'=>'submit']); ?>

												<?php echo Form::close(); ?>


												</td>
											 </tr>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				                        </tbody>
				                    </table>
				                </div>



								  </div>

         <?php endif; ?>
                        </div>

				             <div class="wrap_result"></div>


				            <!-- START COMMENTS -->
				            <div id="comments">



				            </div>
				            <div class="wrap_result"></div>
				          <?php if($sliders): ?>
				          <div class="pagination" align="center">
				             <?php echo e($sliders->links()); ?>

				            <!-- END COMMENTS -->
				            </div>
				          <?php endif; ?>

 </div>


<?php /**PATH /var/www/eosts/resources/views/eosts/admin/sliders/sliders_content.blade.php ENDPATH**/ ?>