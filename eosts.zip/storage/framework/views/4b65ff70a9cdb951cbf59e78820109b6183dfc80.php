<?php if(isset($sliders[0]) > 0): ?>

    <!-- slider -->
    <div class="slider-max loader" id="loader">
        <div class="slider-section" id="slow" style="display:none">


            <div class="home-slider ">
                <?php $__currentLoopData = $sliders[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $z=>$slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



                    <div class="slider-item"
                         style="background-image: url(<?php echo e(asset('/sliders/'.$slider->img['max'])); ?>);">
                        <!-- <div class="slider-item"> -->
                        <!-- <img src="images/banner_slider_2.jpg" alt=""> -->
                        <?php if(isset($slider->name['name'][$sliders[1]])): ?>
                            <div class="h2"><?php echo $slider->name['name'][$sliders[1]]; ?></div>
                        <?php endif; ?>
                        <?php if(isset($slider->name['title'][$sliders[1]])): ?>
                            <div class="h3"><?php echo $slider->name['title'][$sliders[1]]; ?></div>
                        <?php endif; ?>
                        <?php if(isset($slider->name['description'][$sliders[1]])): ?>
                            <div class="h4"><?php echo $slider->name['description'][$sliders[1]]; ?> </div>
                        <?php endif; ?>
                    </div>



                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <style type="text/css">

    </style><?php /**PATH /var/www/eosts/resources/views/eosts/slider.blade.php ENDPATH**/ ?>