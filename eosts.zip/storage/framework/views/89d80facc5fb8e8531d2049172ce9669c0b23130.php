<?php
    if(!session()->has('lang')){
            session()->put('lang', 'ru');
        }
    $lang = session('lang');

$public = substr($_SERVER['REQUEST_URI'], 1,6);  


?>
<?php if($menu): ?>
                        <ul class="navbar-nav ml-auto" itemprop="about" itemscope="" itemtype="#">

                            <li class="nav-item <?php echo e(('ru'==$public)?'active':''); ?><?php echo e(('en'==$public)?'active':''); ?><?php echo e(('tu'==$public)?'active':''); ?>" itemprop="itemListElement" itemscope=""
                                itemtype="http://schema.org/ItemList">
                                <a href="/<?php echo e($lang); ?>" class="nav-link" itemprop="url"><?php echo e(('ru'==$lang)?'Главная':''); ?><?php echo e(('en'==$lang)?'Home':''); ?><?php echo e(('tu'==$lang)?'Ev':''); ?></a>
                                <meta itemprop="name" content="<?php echo e(('ru'==$lang)?'Главная':''); ?><?php echo e(('en'==$lang)?'Address':''); ?><?php echo e(('tu'==$lang)?'Address':''); ?>" />
                            </li>
                            
                      
<?php echo $__env->make(env('THEME').'.customMenuItems',['items'=>$menu->roots()], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 </ul>
<?php endif; ?><?php /**PATH /var/www/eosts/resources/views/eosts/navigation.blade.php ENDPATH**/ ?>