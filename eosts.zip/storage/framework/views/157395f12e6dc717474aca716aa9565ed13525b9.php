<?php $__env->startSection('navigation'); ?>
	<?php echo $navigation; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('slider'); ?>
	<?php echo $slider; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('special'); ?>
	<?php echo $__env->make(env('THEME').'.special', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('features'); ?>
	<?php echo $__env->make(env('THEME').'.features', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('quote'); ?>
	<?php echo $__env->make(env('THEME').'.quote', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('counter'); ?>
	<?php echo $__env->make(env('THEME').'.counter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('otzivi'); ?>
	<?php echo $otzivi; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('clients'); ?>
	<?php echo $naskli; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('ind'); ?>
	<?php echo $content; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('gallery'); ?>
	<?php echo $gallery; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('futnav'); ?>
	<?php echo $futnav; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make(env('THEME').'.layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/eosts/resources/views/eosts/index.blade.php ENDPATH**/ ?>