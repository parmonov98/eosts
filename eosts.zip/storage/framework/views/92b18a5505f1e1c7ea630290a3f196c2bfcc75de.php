<?php if($menu): ?>


		<?php echo $menu->asUl(['class'=>'sidebar-menu ','data-widget'=>'tree','style'=>'margin-top: 15px;', 'data-widget'=>'tree'],['class' => 'treeview-menu']); ?>



<?php endif; ?>



<?php /**PATH /var/www/eosts/resources/views/eosts/admin/navigation.blade.php ENDPATH**/ ?>