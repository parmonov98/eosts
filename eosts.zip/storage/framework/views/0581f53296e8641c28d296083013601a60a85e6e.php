<?php $__env->startSection('navigation'); ?>
	<?php echo $navigation; ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('ind'); ?>
	<?php echo $content; ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('clients'); ?>
	<?php echo $naskli; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('vopros'); ?>
	<?php echo $vopros; ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('callout'); ?>
	<?php echo $__env->make(env('THEME').'.callout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('futnav'); ?>
	<?php echo $futnav; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make(env('THEME').'.layouts.site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/eosts/resources/views/eosts/uslug.blade.php ENDPATH**/ ?>