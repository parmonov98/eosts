<h2><u>EOSTS haqimizda</u></h2>
          <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
              <button class="close" data-dismiss="alert">×</button>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
          <?php endif; ?>
<div id="content-page" class="content group">
				            <div class="hentry group">

<!-- summernote css/js -->
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.js"></script>


<?php echo Form::open(['url' => route('setOnasUp') ,'class'=>'contact-form','method'=>'POST','enctype'=>'multipart/form-data']); ?>




<?php
  $i=0;
  $j=0;
  $languages=['ru'=>'Русский','en'=>'English','tu'=>'Türkçe'];
  ?>
  <div class="col-md-12">
      <ul class="nav nav-tabs">
            <?php foreach ($languages as $language => $label) { ?>
                <li class="<?= ($i==0)?'active':'' ?>"><a data-toggle="tab" href="#<?=$language?>"><?=$label?></a></li>


      <?php $i++; } ?>
        </ul>


    <div class="tab-content">

              <?php foreach ($languages as $language => $label) { ?>
               <div id="<?=$language?>" class="tab-pane fade in <?= ($j==0)?'active':'' ?>">



    <br />



      <div class="input-prepend"><span class="add-on">

      <i class="icon-user"></i></span>
    

EOSTS haqida (<?php echo e($label); ?> tilida):<strong style="color:red;">*</strong> 

     <?php echo Form::textarea('prcomp['.$language.']',  isset($setname->prcomp[$language]) ? $setname->prcomp[$language]  : old("prcomp[$language]"), ['id'=>'summernote','class' => 'form-control','placeholder'=>'Введите текст страницы']); ?>


       </div>




                </div>
            <?php $j++; } ?>
















		<br />

	<?php echo Form::button('Saqlash', ['class' => 'btn btn-block btn-success btn-flat','type'=>'submit']); ?>


<?php echo Form::close(); ?>



</div>
</div>

<!-- summernote css/js -->
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.js"></script>
<script type="text/javascript">
    $('#summernote*').summernote({
        height: 250
    });
</script><?php /**PATH /var/www/eosts/resources/views/eosts/admin/settings/onas_content.blade.php ENDPATH**/ ?>