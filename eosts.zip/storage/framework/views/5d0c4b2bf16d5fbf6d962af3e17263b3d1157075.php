
	<div id="content-page" class="content group">
				            <div class="hentry group">
										 <?php echo Html::link(route('maps.create'),'+',['class' => 'btn btn-primary btn-lg','style'=>'margin-bottom: 5px;']); ?>

				               <strong style="font-size: 2rem; padding: 10px; " align="right"> Google xarita </strong>
    <?php if($status = Session::get('status')): ?>
	<div class="alert alert-success">
	<button class="close" data-dismiss="alert">×</button>
	<strong><?php echo e($status); ?></strong>
	</div>									
    <?php endif; ?>
    <?php if($error = Session::get('error')): ?>
	<div class="alert alert-danger">
	<button class="close" data-dismiss="alert">×</button>
	<strong><?php echo e($error); ?></strong>
	</div>									
    <?php endif; ?>


				        <div class="short-table white">




<hr>



<?php if($maps->count()>0): ?>
	        <table  class="table table-striped table-hover" style="width: 100%" cellspacing="0" cellpadding="0">
	                        <thead>
	                            <tr >
	                                <th style="width: 50px;text-align: center;">ID</th>
	                                <th>Nomlanishi</th>
	                                <th style="width: 50px;text-align: center;"><i class="fa fa-pencil-square-o"></i></th>
	                                <th style="width: 50px;text-align: center;"><i class="fa fa-trash-o"></i></th>
	                            </tr>
	                        </thead>
	                        <tbody>

											<?php $__currentLoopData = $maps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$map): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											
											<tr>
				                                <td style="text-align: center;"><?php echo e(++$key); ?></td>
		                                <td class="align-left">
		                              
		                                	<?php echo e($map->title['ru']); ?>


		                               </td>

              <td>
               <a href="<?php echo e(route('maps.edit',['map'=>$map->id])); ?>" class="btn btn-success"><i class="fa fa-pencil-square-o"></i></a>	
              </td>
				                                
				                        

				                                <td>
								 <?php if(Gate::allows('DELETE_ARTICLES')): ?>

												<?php echo Form::open(['url' => route('maps.destroy',['map'=>$map->id]),'class'=>'form-horizontal','method'=>'POST']); ?>

												    <?php echo e(method_field('DELETE')); ?>

												    <?php echo Form::button('<i class="fa fa-trash-o"></i>', ['class' => 'btn btn-danger','type'=>'submit']); ?>

												<?php echo Form::close(); ?>

										<?php endif; ?>


												</td>
											 </tr>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				                        </tbody>
				                    </table>
				      
         <?php endif; ?>



















				             <div class="wrap_result"></div>


				            <!-- START COMMENTS -->
				            <div id="comments">



				            </div>
				            <div class="wrap_result"></div>
				          <?php if($maps): ?>
				          <div class="pagination" align="center">
				             <?php echo e($maps->links()); ?>

				            <!-- END COMMENTS -->
				            </div>
				          <?php endif; ?>

 </div>


<?php /**PATH /var/www/eosts/resources/views/eosts/admin/maps/maps_content.blade.php ENDPATH**/ ?>