
<?php if($comment): ?>
	<div id="content-page" class="content group">
				            <div class="hentry group">
				                <h2>Вопрос или предложение <?php echo e($comment->name?$comment->name:''); ?></h2>
				                <div class="short-table white"> 


<hr>

<div class="row">
	<div class="col-md-6">
<p><strong>Имя:</strong> <?php echo e($comment->name); ?></p>
<p><strong>E-mail:</strong> <?php echo e($comment->email); ?></p>
<p><strong>Телифон:</strong> <?php echo $comment->phone; ?></p>
<p><strong>Текст:</strong> <?php echo $comment->message; ?></p>
	</div>
	<div class="col-md-6">

<?php if(isset($comment->incoterms)): ?><p><strong>Тип груз:</strong> <?php echo e($comment->incoterms); ?></p><?php endif; ?>
<?php if(isset($comment->package)): ?><p><strong>Инкотермс:</strong> <?php echo $comment->package; ?></p><?php endif; ?>
<?php if(isset($comment->city_of_departure)): ?><p><strong>Город отправления:</strong> <?php echo e($comment->city_of_departure); ?></p><?php endif; ?>
<?php if(isset($comment->weight)): ?><p><strong>Общий вес груза (кг):</strong> <?php echo $comment->weight; ?></p><?php endif; ?>
<?php if(isset($comment->dimension)): ?><p><strong>Город доставки:</strong> <?php echo $comment->dimension; ?></p><?php endif; ?>


	</div>
</div>




			</div>
			<div class="msg-error"></div>


	            <div class="pull-left">
                <a class="btn btn-primary" href="<?php echo e(route('requ.index')); ?>"> Back</a>
            </div>

	
				        </div>
				        </div>
				        </div>
<?php endif; ?>

<?php /**PATH /var/www/eosts/resources/views/eosts/admin/requ/requ_create_content.blade.php ENDPATH**/ ?>