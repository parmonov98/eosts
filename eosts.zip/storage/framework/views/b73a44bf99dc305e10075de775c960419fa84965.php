	<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <!--          
                    $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
                    if (Request::url() === $actual_link) {
                        $act = 'active';
                    }else{$act='';} 
                    
 -->
 

 <li class="nav-item <?php echo e(($item->active)?'active':''); ?>" itemprop="itemListElement" itemscope="" itemtype="#">

        <a class="nav-link <?php echo e(($item->active)?'active':''); ?>" href="<?php echo e(($item->hasChildren())?'#':$item->url()); ?>"><?php echo e($item->title); ?></a><meta itemprop="name" content="<?php echo e($item->title); ?>" />

        <?php if($item->hasChildren()): ?>
             <ul class="submenu">
                <?php echo $__env->make(env('THEME').'.customMenuItems',['items'=>$item->children()], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			</ul>
        <?php endif; ?>

    </li>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php /**PATH /var/www/eosts/resources/views/eosts/customMenuItems.blade.php ENDPATH**/ ?>