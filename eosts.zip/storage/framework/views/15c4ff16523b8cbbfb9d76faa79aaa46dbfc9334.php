<h2><u>Tashkilot nomi</u></h2>
          <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
              <button class="close" data-dismiss="alert">×</button>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
          <?php endif; ?>
<div id="content-page" class="content group">
				            <div class="hentry group">

<?php echo Form::open(['url' => route('setNamesup') ,'class'=>'contact-form','method'=>'POST','enctype'=>'multipart/form-data']); ?>





			<div class="input-prepend"><span class="add-on"><i class="icon-user"></i></span>

				Русский:<input type="text" name="name[ru]" value="<?php echo e(isset($setname['names']['name']['ru']) ? $setname['names']['name']['ru'] : ''); ?>" placeholder="Русский" class="form-control">

				English:<input type="text" name="name[en]" value="<?php echo e(isset($setname['names']['name']['en']) ? $setname['names']['name']['en'] : ''); ?>" placeholder="English" class="form-control">

				Türkçe:<input type="text" name="name[tu]" value="<?php echo e(isset($setname['names']['name']['tu']) ? $setname['names']['name']['tu'] : ''); ?>" placeholder="Türkçe" class="form-control">


			 </div>



    		<hr>
		</div>




						<?php echo Form::button('Saqlash', ['class' => 'btn btn-block btn-success btn-flat','type'=>'submit']); ?>



<?php echo Form::close(); ?>



</div>


<?php /**PATH /var/www/eosts/resources/views/eosts/admin/settings/names_content.blade.php ENDPATH**/ ?>