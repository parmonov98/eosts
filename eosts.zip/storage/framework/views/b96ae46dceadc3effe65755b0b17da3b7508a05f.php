<?php
if(!session()->has('lang')){session()->put('lang', 'ru');}
$lang = session('lang');
    ?>







        <!-- Page Breadcrumbs Start -->
        <div class="slider bg-navy-blue bg-scroll pos-rel breadcrumbs-page">
            <div class="container">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="/"><i class="icofont-home"></i></a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo e(('ru'==$lang)?'О нас':''); ?><?php echo e(('en'==$lang)?'About Us':''); ?><?php echo e(('tu'==$lang)?'Hakkımızda':''); ?></li>
                    </ol>
                </nav>

                <h1><?php echo e(('ru'==$lang)?'О нас':''); ?><?php echo e(('en'==$lang)?'About Us':''); ?><?php echo e(('tu'==$lang)?'Hakkımızda':''); ?></h1>
                <div class="breadcrumbs-description">
<?php echo e(('ru'==$lang)?'Познакомьтесь с замечательной командой, стоящей за этим проектом, и узнайте больше о том, как мы работаем.':''); ?><?php echo e(('en'==$lang)?'Meet the amazing team behind this project and learn more about how we work.':''); ?><?php echo e(('tu'==$lang)?'Bu projenin arkasındaki harika ekiple tanışın ve nasıl çalıştığımız hakkında daha fazla bilgi edinin.':''); ?>


                </div>
            </div>
        </div>
        <!-- Page Breadcrumbs End -->

        <!-- Main Body Content Start -->
        <main id="body-content">
            <!-- What Makes Us Special Start -->
            <section class="wide-tb-80" itemscope itemtype="https://schema.org/Organization">
                <div class="container pos-rel">
                    <div class="row align-items-center">
                        <div class="col-md-6 wow fadeInLeft" data-wow-duration="0" data-wow-delay="0s">

                            <h2 class="mb-4 fw-7 txt-blue">
                <?php echo e(('ru'==$lang)?'Про':''); ?><?php echo e(('en'==$lang)?'About':''); ?><?php echo e(('tu'==$lang)?'EOSTS':''); ?>

                 <span class="fw-6 txt-orange" itemprop="name"><?php echo e(('ru'==$lang)?'EOSTS':''); ?><?php echo e(('en'==$lang)?'EOSTS':''); ?><?php echo e(('tu'==$lang)?'hakkında':''); ?></span>

                       
                          </h2>

                           <?php echo isset($pronas->prcomp[$lang])?$pronas->prcomp[$lang]:''; ?>


                        </div>

                        <div class="col-md-6 wow fadeInRight" data-wow-duration="0" data-wow-delay="0s">
                 <?php echo Html::style(env('THEME').'/css/select2.min.css'); ?>  


<div class="norma">
            
<select class="form-control select2" name="smaps" id="smap">
   
<?php 
foreach ($allmaps as $key => $map) { 
  echo '<option value="'.$map->id.'">'.$map->title[$lang].'</option>';
} 
?>


</select>


 </div>

<div id="iframe">
<iframe width="550" height="450" src="https://maps.google.com/maps?width=600&amp;height=450&amp;hl=en&amp;coord=<?php echo e($maps->longitu); ?>, <?php echo e($maps->latitu); ?>&amp;q=<?php echo e($maps->title[$lang]); ?>&amp;ie=UTF8&amp;t=&amp;z=14&amp;iwloc=B&amp;output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe><br />

</div>


                        </div>
                    </div>
                </div>
            </section>
            <!-- What Makes Us Special End -->







<section class="bg-light-gray wide-tb-100 pb-5 why-choose">
        <div class="container pos-rel">
          <div class="row">
            <!-- Heading Main -->
            <div class="col-sm-12 wow fadeInDown" data-wow-duration="0" data-wow-delay="0s">
              <h1 class="heading-main">


<?php echo ('ru'==$lang)?'<span>НАШИ ОСОБЕННОСТИ </span> Почему именно нас выбирают?':''; ?>

<?php echo ('en'==$lang)?'<span> OUR FEATURES </span> Why choose us?':''; ?>

<?php echo ('tu'==$lang)?'<span> ÖZELLİKLERİMİZ </span> Neden bizi seçmelisiniz?':''; ?>


                
              </h1>
            </div>
            <!-- Heading Main -->




 <?php echo isset($pronas->question[$lang])?$pronas->question[$lang]:''; ?>

          


          </div>
        </div>
      </section>













<section class="wide-tb-100 mb-spacer-md">
        <div class="container wide-tb-100 pb-0">
          <div class="row d-flex align-items-center">
            
<?php echo isset($pronas->select[$lang])?$pronas->select[$lang]:''; ?>              

              
          </div>
        </div>
      </section>







            <!-- Tracking Your Freight Start -->
            <section class="pos-rel bg-light-gray">
                <div class="container-fluid">
                    <div class="row align-items-center">
                        <div class="col-lg-5 col-12 p-0">
                            <img src="<?php echo e(asset(env('THEME').'/images/why-choose-us.jpg')); ?>" class="w-100" alt="" />
                        </div>
                        <div class="col-lg-6 col-12">
                            <div class="p-5 about-whoose">
                                <?php echo isset($pronas->vebor[$lang])?$pronas->vebor[$lang]:''; ?>    
                                  

                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Tracking Your Freight End -->


<?php if($employee->count()>0): ?>
            <!-- Our Team Start -->
            <section class="wide-tb-100 pb-0 team-section-bottom pos-rel">
                <div class="container">
                    <!-- Heading Main -->
                    <div class="col-sm-12">
                        <h1 class="heading-main">
                            <?php if('ru'==$lang): ?> <span>Кто стоит за EOSTS</span> Наша команда <?php elseif('en'==$lang): ?> <span> Who is behind EOSTS </span> Our team <?php else: ?> <span> EOSTS'un arkasında kim var </span> <?php endif; ?>

                            
                        </h1>
                    </div>
                    <!-- Heading Main -->

                    <div class="row pb-4">
                        <!-- Team Column One -->
                         <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r=>$emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                        <div class="col-sm-12 col-md-4 wow fadeInUp" data-wow-duration="0" data-wow-delay="0.<?php echo e($r); ?>s">


                            <div class="team-section-two">
                                <img src="<?php echo e(asset('/uploads/'.$emp->img)); ?>" alt="" class="rounded" />
                                <h4 class="h4-md txt-orange"><?php echo e($emp->name[$lang]); ?></h4>
                                <h5 class="h5-md txt-white"><?php echo e($emp->prof[$lang]); ?></h5>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!-- Team Column One -->
     
                    </div>
                </div>
            </section>
            <!-- Our Team End -->
<?php endif; ?>

        </main>
<?php echo Html::script(env('THEME').'/js/select2.full.min.js'); ?>

<style type="text/css">
    .norma{
       position: absolute;
        max-width: 152px;
        right: 0px;
        top: 10px; 
    }

 @media (min-width: 767.99px) {
       .norma{
       position: absolute;
        max-width: 200px;
        right: 15px;
        top: 10px; 
    }
 }   
</style>


        <?php echo Html::script(env('THEME').'/js/fontawesome-all.js'); ?>

        <script type="text/javascript" src="https://maps.google.com/maps/api/js?sensor=false"></script>
        <?php echo Html::script(env('THEME').'/js/jquery.gmap.min.js'); ?>

        <?php echo Html::script(env('THEME').'/js/gmaps.js'); ?>


<script type="text/javascript">

$(document).ready(function(){

$('#smap').on('click',function(e) {
    e.preventDefault(); 
    var smap = $('#smap').val();


       $.ajax({
            url:"<?php echo e(route('selmap')); ?>",
            data:{"_token":$('meta[name="csrf-token"]').attr('content'),smap: smap},
            type:'POST',
            datatype:'JSON',
            success: function(html) { 
                $('#iframe').html(html);      
            },
            error:function() {
                $('#salom').css('color','red').append('<strond>Ошибка: </strong>');
                $('#salom').delay(2000).fadeOut(500);
            }
        });



});

});   
    

</script><?php /**PATH /var/www/eosts/resources/views/eosts/pronas.blade.php ENDPATH**/ ?>