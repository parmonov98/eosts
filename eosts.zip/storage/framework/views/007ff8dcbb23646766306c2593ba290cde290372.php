
	<div id="content-page" class="content group">
				            <div class="hentry group">
										 <?php echo Html::link(route('nakil.create'),'+',['class' => 'btn btn-primary btn-lg','style'=>'margin-bottom: 5px;']); ?>

				               <strong style="font-size: 2rem; padding: 10px; " align="right"> Наши клиенты </strong>
    <?php if($status = Session::get('status')): ?>
	<div class="alert alert-success">
	<button class="close" data-dismiss="alert">×</button>
	<strong><?php echo e($status); ?></strong>
	</div>									
    <?php endif; ?>
    <?php if($error = Session::get('error')): ?>
	<div class="alert alert-danger">
	<button class="close" data-dismiss="alert">×</button>
	<strong><?php echo e($error); ?></strong>
	</div>									
    <?php endif; ?>


				        <div class="short-table white">




<?php if($setname): ?>
<div class="card-body">
                <div class="row">
<?php $__currentLoopData = $setname; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="col-sm-3" style=" padding-bottom: 5px;">
                  <?php if(isset($file->img)): ?>
                  <a href="<?php echo e(route('nakil.edit',['nakil'=>$file->id])); ?>" >
				<?php echo e(Html::image(asset('/nakil/'.$file->img),'',['style'=>'width:100%;'])); ?>

			</a>
													<?php endif; ?>
<?php echo Form::open(['url' => route('nakil.destroy',['nakil'=>$file->id]),'class'=>'form-horizontal','method'=>'POST']); ?>

	    <?php echo e(method_field('DELETE')); ?>

	    <?php echo Form::button('<i class="fa fa-trash-o"></i>', ['class' => 'btn btn-danger btn-block','type'=>'submit']); ?>

	<?php echo Form::close(); ?>

                  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <?php endif; ?>







 </div> </div>








				             <div class="wrap_result"></div>


				            <!-- START COMMENTS -->
				            <div id="comments">



				            </div>
				            <div class="wrap_result"></div>
				          <?php if($setname): ?>
				          <div class="pagination" align="center">
				             <?php echo e($setname->links()); ?>

				            <!-- END COMMENTS -->
				            </div>
				          <?php endif; ?>

 </div>


<?php /**PATH /var/www/eosts/resources/views/eosts/admin/nakil/nakils_content.blade.php ENDPATH**/ ?>