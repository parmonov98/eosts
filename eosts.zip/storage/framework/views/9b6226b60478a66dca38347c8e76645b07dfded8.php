<h2><u>Barcha buyurtmalar</u></h2>
	
	<div id="content-page" class="content group">
				            <div class="hentry group">
    <?php if($status = Session::get('status')): ?>
	<div class="alert alert-success">
	<button class="close" data-dismiss="alert">×</button>
	<strong><?php echo e($status); ?></strong>
	</div>									
    <?php endif; ?>
    <?php if($error = Session::get('error')): ?>
	<div class="alert alert-danger">
	<button class="close" data-dismiss="alert">×</button>
	<strong><?php echo e($error); ?></strong>
	</div>									
    <?php endif; ?>




<?php if($requs->count()>0): ?>

<table class="table table-striped table-bordered table-hover" width="100%">

<thead> 
	<tr> 
		<th>#</th> 
		<th>Ism</th> 
		<th>Telefon</th> 
		<th>E-mail</th> 
		<th>Xizmat turi</th> 
		<th>Junatilish vaqtlari</th> 
		<th style="width: 50px;text-align: center;"><i class="fa fa-eye"></i></th>
		<th style="width: 50px;text-align: center;"><i class="fa fa-trash-o"></i></th>
	</tr> 
</thead>

<tbody>
<?php $__currentLoopData = $requs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$requ): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr <?php echo ($requ->prev == 0)?'style="color: red;"':''; ?>>
		<td><?php echo e(++$k); ?></td>
		<td><?php echo e($requ->name); ?></td>
		<td><?php echo e($requ->phone); ?></td>
		<td><?php echo e($requ->email); ?></td>
		<td><?php echo e($requ->package); ?></td>
		<td><?php echo e(is_object($requ->created_at) ? $requ->created_at->format('F d, Y') : ''); ?></td>
		<td>

	<a href="<?php echo e(route('requ.edit',['requ' => $requ->id])); ?>" class="btn btn-success">
		<i class="fa fa-eye"></i></a>
	
	</td>
<td><?php echo Form::open(['url' => route('requ.destroy',['requ'=>$requ->id]),'class'=>'form-horizontal','method'=>'POST']); ?>

<?php echo e(method_field('DELETE')); ?>

<?php echo Form::button('<i class="fa fa-trash-o"></i>', ['class' => 'btn btn-danger','type'=>'submit']); ?>

<?php echo Form::close(); ?>

</td>

	</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<?php else: ?>
<h2 style="text-align: center;color: red;">Buyurtma yo'q !!!</h2>
  <?php endif; ?>

				        <div class="short-table white">




				             <div class="wrap_result"></div>


				            <!-- START COMMENTS -->
				            <div id="comments">



				            </div>
				            <div class="wrap_result"></div>
				          <?php if($requs): ?>
				          <div class="pagination" align="center">
				             <?php echo e($requs->links()); ?>

				            <!-- END COMMENTS -->
				            </div>
				          <?php endif; ?>

 </div>


<?php /**PATH /var/www/eosts/resources/views/eosts/admin/requ/requs_content.blade.php ENDPATH**/ ?>