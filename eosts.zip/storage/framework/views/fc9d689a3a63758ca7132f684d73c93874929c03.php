

<div class="row">
    <h2 class="text-center ">Bosh sahifa</h2>




    <div class="col-lg-12 col-md-2 main-chart">

        <div class="mtbox">

<a href="<?php echo e(route('uslug.index')); ?>">
            <div class="col-md-3 col-sm-2 box0">
                <div class="box1">
                    <span class="fa fa-handshake-o"></span>
                    <h3>Xizmatlar</h3>
                </div>
                <!-- <p><?php echo e($user); ?></p> -->
            </div>
</a>

<a href="<?php echo e(route('nakil.index')); ?>">
            <div class="col-md-3 col-sm-2 box0">
                <div class="box1">
                    <span class="fa fa-child"></span>
                    <h3>Bizning mijozlarimiz</h3>
                </div>
                <!-- <p><?php echo e($user); ?></p> -->
            </div>
</a>


<a href="<?php echo e(route('requ.index')); ?>">
            <div class="col-md-3 col-sm-2 box0">
                <div class="box1">
                    <span class="fa fa-paste"></span>
                    <h3>Buyurtmalar</h3>
                </div>
                <!-- <p><?php echo e($user); ?></p> -->
            </div>
</a>


<a href="<?php echo e(route('contact.index')); ?>">
            <div class="col-md-3 col-sm-2 box0">
                <div class="box1">
                    <span class="fa fa-envelope-open"></span>
                    <h3>Xabarlar</h3>
                </div>
                <!-- <p><?php echo e($user); ?></p> -->
            </div>
</a>

<a href="<?php echo e(route('setVopraos')); ?>">
            <div class="col-md-3 col-sm-2 box0">
                <div class="box1">
                    <span class="fa fa-share-alt"></span>
                    <h3>Savollar</h3>
                </div>
                <!-- <p><?php echo e($user); ?></p> -->
            </div>
</a>


<a href="<?php echo e(route('otziv.index')); ?>">
            <div class="col-md-3 col-sm-2 box0">
                <div class="box1" style="padding: 15px 0px;">
                    <span class="fa fa-id-card-o"></span>
                    <h3  style="font-size: 22px;">Mijozlarning sharhlari</h3>
                </div>
                <!-- <p><?php echo e($user); ?></p> -->
            </div>
</a>


<a href="<?php echo e(route('slider.index')); ?>">
            <div class="col-md-3 col-sm-2 box0">
                <div class="box1">
                    <span class="fa fa-picture-o"></span>
                    <h3>Slayder</h3>
                </div>
                <!-- <p><?php echo e($user); ?></p> -->
            </div>
</a>


<a href="<?php echo e(route('gallery.index')); ?>">
            <div class="col-md-3 col-sm-2 box0">
                <div class="box1">
                    <span class="fa fa-camera"></span>
                    <h3>Galereya</h3>
                </div>
                <!-- <p><?php echo e($user); ?></p> -->
            </div>
</a>






        </div><!-- /row mt -->
    </div>


 



</div>












<div class="card-body">
                <div class="row">

                  <div class="col-sm-2" style=" padding-bottom: 5px;">







                  </div>







 </div> </div>

<?php /**PATH /var/www/eosts/resources/views/eosts/admin/index_view.blade.php ENDPATH**/ ?>