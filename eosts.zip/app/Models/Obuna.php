<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Obuna extends Model
{
     protected $table = 'obuna';
     protected $fillable = ['email'];
}