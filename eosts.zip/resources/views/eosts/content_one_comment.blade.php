                    <div class="media pb-5">
                      <img class="thumb rounded-circle" src="https://www.gravatar.com/avatar/{{$data['hash']}}?d=mm&s=75" alt="">
                      <div class="media-body">
                        <div class="border-style d-md-flex justify-content-between">
                          <h4 class="h4-xs txt-orange">{{$data['name']}}</h4>

                        </div>{{$data['text']}}
                        <p><a href="#" class="btn-theme bg-navy-blue mt-3">Reply <i class="icofont-ui-reply"></i></a>
                        </p>
                      </div>
                    </div>