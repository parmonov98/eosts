<footer id="footer"><!--Footer-->
		<div class="footer-top">
			<div class="container">
				<div class="row">
					<div class="col-sm-2">
						<div class="companyinfo">
							<h2>Salom1</h2>
							<p>Salom1</p>
						</div>
					</div>
					
					<div class="col-sm-2">
						<div class="companyinfo">
							<h2>Salom2</h2>
							<p>Salom2</p>
						</div>
					</div>
					
					<div class="col-sm-2">
						<div class="companyinfo">
							<h2>Salom3</h2>
							<p>Salom3</p>
						</div>
					</div>

					<div class="col-sm-2">
						<div class="companyinfo">
							<h2>Salom4</h2>
							<p>Salom4</p>
						</div>
					</div>										
					
				</div>
			</div>
		</div>
		
		
		
		<div class="footer-bottom">
			<div class="container">
				<div class="row">
					<p class="pull-left">Oxirgi yangilanish sanasi: {{ date("M Y") }}</p>
					<p class="pull-right">Bog`lanish</span></p>
				</div>
			</div>
		</div>
		
	</footer><!--/Footer-->